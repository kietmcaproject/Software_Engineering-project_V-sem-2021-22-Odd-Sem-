*******************
Project Details:
*******************

Project Title:- Office Management System

Users:

1.Administrator

2.Staff

**************************
Module Specification:
**************************

1.Admin

1.Manage Department.

2.Manage Staff.

3.Manage Salary.

4.Download Invoice.

5.Manage Leave.

2.Staff

1.Login to the Portal.

2.View Salary.

3.Download Invoice.

4.Apply for Leave.


Note: This project is not a perfectly functional one. You can try making changes yourself for making it better.


*******************
How To Run The Project?
*******************

To run this project, you must have installed a virtual server i.e XAMPP on your PC (for Windows). This Interview Management System is in PHP with source code is free to download, Use for educational purposes only!

After Starting Apache and MySQL in XAMPP, follow the following steps.

1st Step: Extract file

2nd Step: Copy the main project folder

3rd Step: Paste in xampp/htdocs/

4rd Step: Change base url in application/config/config.php to "http://localhost/Ofiice-Management-System/"

5th Step: Open a browser and go to URL “http://localhost/phpmyadmin/”

6th Step: Then, click on the databases tab

7th Step: Create a database naming “thub_office” and then click on the import tab

8th Step: Click on browse file and select “thub_office.sql” file which is inside the “database” folder.

8th Step: Click on go.

After Creating Database,

9th Step: Open a browser and go to URL “http://localhost/Ofiice-Management-System/”

NOTE: Check database for login details. 
