  <footer class="footer text-center text-muted">
                <p style="color: red">Meal Manager</p>
            </footer>