<section class="fabout">
		<div class="section white center">
		      <div class="row container">
		        <h2 class="header">ABOUT US</h2>
		        <p class="grey-text text-darken-3 lighten-3">If you are hungry and need some refreshments after a long routine class, then try our delecious food. You can order online food inside your campus and you can get your food delivered in your classroom or any place inside the campus.</p>
				<a href="/RestroGirls/about-restro-girls.php" class="waves-effect waves-light btn" style="background: #ee6e73 !important;">Read More &raquo;</a>
		      </div>
	</section>