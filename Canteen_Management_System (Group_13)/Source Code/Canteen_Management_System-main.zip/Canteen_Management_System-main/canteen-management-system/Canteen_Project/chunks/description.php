<section class="fdes">
		<div class="section white center">
			<h2 class="header" style="padding:20px; padding-bottom: 30px;">Your College Canteen</h2>
		      <div class="row container center">
		        <div class="col center l8 s12">
		        	<p>GOOD FOOD GOOD LIFE GOOD STUDY</p>
		        </div>
		        <div class="col center l4 s12">
		        	<img height="300" width="auto" style="object-fit: contain;" src="images/17964.jpg" alt="">
		        </div>
		        
		      </div>
	</section>