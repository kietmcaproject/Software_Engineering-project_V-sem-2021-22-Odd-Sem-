	<div class="footer">
		<div class="container">
			<p class="wow fadeInLeft" data-wow-delay="0.4s">&copy; Meal Manager &nbsp;</p><br>
			<p class="wow fadeInLeft" data-wow-delay="0.4s">&copy; KIET Group Of Institutions &nbsp;</p><br>

		</div>
	</div>